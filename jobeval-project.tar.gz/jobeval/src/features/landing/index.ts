export { default as LandingPage } from "./components/LandingPage";
